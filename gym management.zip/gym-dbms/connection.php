<?php

$con=mysqli_connect("localhost", "root", "", "gym_db");

if(mysqli_connect_error())
{
    echo "cannot connect";
}

?>