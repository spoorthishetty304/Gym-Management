<?php

include 'connection.php';

$trainer_id = $_GET['trainer_id'];

$deletequery = "DELETE FROM `trainers_tbl` WHERE  trainer_id=$trainer_id ";

$result = mysqli_query($con,$deletequery); 

header('location:trainerlist.php');

?>
