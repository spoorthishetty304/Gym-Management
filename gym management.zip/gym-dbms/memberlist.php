<?php

require("connection.php");
$query = "SELECT * FROM members_tbl";
$search_result = mysqli_query($con,$query);
$trquery = "SELECT T.fname FROM trainers_tbl T , members_tbl M WHERE T.trainer_id=M.trainer_id";
$tr = mysqli_query($con,$trquery);
// $trname=mysqli_fetch_assoc($tr);

?>
<?php

if(isset($_POST['submit']))
{
    $valurToSearch = $_POST['search'];
    $query2 = "SELECT * FROM `members_tbl` WHERE CONCAT(`member_id`, `fname`, `lname`, `email`, `phone`, `trainer_id`, `valid_till`)LIKE '%" . $valurToSearch . "%';";
    $search_result = filterTable($query2);
}
else
{
    $query1 = "SELECT * FROM members_tbl";
    $search_result = filterTable($query1);
}

function filterTable($query1)
{
    require("connection.php");
    $filter_result = mysqli_query($con, $query1);
    return $filter_result;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/3562685406.js" crossorigin="anonymous"></script>
    <title>Member</title>
</head>
<body>
    <section>
        <div class="top">
            <a href="memberregister.html">
            <div class="back">
                    <span class="ba">BACK</span>
            </div></a>
            <div class="title"> 
                GYM MANAGEMENT SYSTEM
            </div>
        </div>
    </section>
    <section>
        <div class="bottom">
            <div class="list_text">
                <h1 class="text">
                    <i style="font-size:30px" class="fas">&#xf0c9;</i>
                    MEMBERS LIST
                </h1>
                <a href="memberregister.html">
                    <button class="button">
                        <h3>
                        <i style="font-size:16px" class="fa">&#xf067;</i>
                        ADD MEMBER
                        </h3>
                    </button>
                </a>
            </div>
            <div class="search_box">
                <form action="" method="post">
                <input type="search" name="search" class="box1" placeholder="  SEARCH FOR MEMBER">
                <input type="submit" name="submit" value="SEARCH" class="box2">
                </form>
            </div>
            <div class="info">
                <table class="table">
                    <tr class="tr">
                        <th class="td">MEMBER_ID</th>
                        <th class="td">NAME</th>
                        <th class="td">EMAIL ID</th>
                        <th class="td">PHONE NUMBER</th>
                        <th class="td">TRAINER_NAME</th>
                        <th class="td">VALID TILL</th>
                        <th class="td">OPERTIONS</th>
                    </tr>
                    <?php
                    while($rows=mysqli_fetch_assoc($search_result))
                    {
                        $trname=mysqli_fetch_assoc($tr);
                        $last=$rows['fname'];
                    ?>
                        <tr>
                            <td style="border-bottom: 1px solid black;"> <?php echo $rows['member_id']; ?></td>
                            <td style="border-bottom: 1px solid black;"> <?php echo $rows['fname'];?></td>
                            <td style="border-bottom: 1px solid black;"> <?php echo $rows['email'];?></td>
                            <td style="border-bottom: 1px solid black;"> <?php echo $rows['phone'];?></td>
                            <td style="border-bottom: 1px solid black;"> <?php foreach($trname as $trainername){
        echo $trainername;}?></td>
                            <td style="border-bottom: 1px solid black;"> <?php echo $rows['valid_till'];?></td>
                            <td style="border-bottom: 1px solid black;">
                            <!-- <a href="update1.php?mid=<?php echo $rows['member_id']?>" ?> <data-toggle="tooltip" data-placement="bottom" title="update">
                                <i class="fa" aria-hidden="true" style="font-size: x-large; color: green;">&#xf044;</i></a> -->
                            <a href="deletemember.php?member_id=<?php echo $rows['member_id']; ?>" data-toggle="tooltip" data-placement="bottom" title="delete">
                                <i class="fa" aria-hidden="true" style="font-size: x-large; color: red;">&#xf014;</i></a>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                    
                </table>
            </div>
        </div>
    </section>
</body>
</html>

<style>
     *{
    margin: 0 0;
    padding: 0 0;
    }

    .top{
        border: 1 px solid whitesmoke;
        width: 100%;
        height: 60px;
        margin: 0 auto;
        background-color: rgb(30, 124,255);
    }

    .title{
        font-size: xx-large;
        text-align: center;
        position: absolute;
        top: 10px;
        left: 450px;
        color: white;
    }

    .back{
        color: white;
        position: relative;
        top: 9px;
        left: 16px;
    }

    .ba{
        font-size: larger;
        font-weight: bolder;
        position: relative;
        top: 10px;
        left: 34px;
    }

    .bottom{
        margin: 20px 40px;
        height: 80rem;
        border: 1px solid grey;
        border-radius: 5px;
        background-color: white;
    }

    .list_text{
        border-bottom: 1px solid black;
        margin: auto 10px;
        text-align: left;
        padding: 18px;
    }

    .text{
        font-size: 2rem;
        font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
    }

    .button{
        width: 160px;
        height: 40px;
        position: absolute;
        top: 97px;
        right: 90px;
        border: 02px solid grey;
        border-radius: 5px;
    }

    

    .box1{
        width: 400px;
        height: 30px;
        outline: none;
        position: absolute;
        top: 190px;
        left: 380px;
        border: 0.1px solid grey;
        border-radius: 5px;
    }

    .box2{
        width: 80px;
        height: 30px;
        background-color: rgb(30, 124,255);
        border: 0.1px solid grey;
        position: absolute;
        top: 190px;
        left: 780px;
        border-radius: 5px;
    }

    .info{
        margin: auto 10px;
        height: 150px;
    }
    .list{
        display: inline;
        padding: 30px;
        position: relative;
        top: 120px;
    }

    .table{
        text-align: center;
        width: 100%;
        height: 110px;
        border: 1px solid grey;
        line-height: 60px;
        position: relative;
        top: 90px;
    }
    .td{
        border-bottom: 1px solid black;
        background-color: rgb(30, 124, 255);
        width: 10%;
    }




</style> 