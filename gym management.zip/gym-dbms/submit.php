<?php
function filtertable($query){
    $con=mysqli_connect("localhost", "root", "", "gym_dbms");
    $filter_result = mysqli_query($con,$query);
    return $filter_result;
}


?>


<?php

$trquery = "SELECT T.fname FROM trainers_tbl T , members_tbl M WHERE T.trainer_id=M.trainer_id";
$tr = mysqli_query($con,$trquery);
$trname=mysqli_fetch_assoc($tr);

if(isset($_POST['submit']))
{
    $query = "SELECT * FROM `members_tbl` WHERE `member_id`='$_POST[search]'";
    
}
else{
    $query = "SELECT * FROM members_tbl";
    $search_result = filtertable($query);
}

?>

<?php
                    while($rows=mysqli_fetch_assoc($search_result))
                    {
                    ?>
                        <tr>
                            <td> <?php echo $rows['member_id']; ?></td>
                            <td> <?php echo $rows['fname'];?></td>
                            <td> <?php echo $rows['email'];?></td>
                            <td> <?php echo $rows['phone'];?></td>
                            <td> <?php foreach($trname as $trainername){
        echo $trainername;}?></td>
                            <td> <?php echo $rows['valid_till'];?></td>
                        </tr>
                    <?php
                    }
                    ?>