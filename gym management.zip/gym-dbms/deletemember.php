<?php

include 'connection.php';

$member_id = $_GET['member_id'];

$deletequery = "DELETE FROM `members_tbl` WHERE  member_id=$member_id ";

$result = mysqli_query($con,$deletequery);

header('location:memberlist.php');

?>
